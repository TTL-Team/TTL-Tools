Unicode 编码
==============

Unicode编码有以下四种编码方式：

源文本： The
 * &#x [Hex]： &#x0054;&#x0068;&#x0065;
 * &# [Decimal]： &#00084;&#00104;&#00101;
 * \U [Hex]： \U0054\U0068\U0065
 * \U+ [Hex]： \U+0054\U+0068\U+0065




## Reference 
 * <http://www.mxcz.net/tools/Unicode.aspx>


