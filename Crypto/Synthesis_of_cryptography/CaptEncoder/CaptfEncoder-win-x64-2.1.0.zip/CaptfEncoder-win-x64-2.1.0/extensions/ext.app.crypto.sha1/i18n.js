module.exports = { 
    messages: {
        en: { 
            message: {
                title: 'SHA1',
                encode_text: 'Encrypt',               
            }
            
        },
        zh: { 
            message: {
                title: 'SHA1',
                encode_text: '加密',               
            }
        },
    }
}