module.exports = { 
    messages: {
        en: { 
            message: {
                title: 'Bcrypt',
                encode_text: 'Encrypt',              
                rounds: 'Rounds',             
            }
            
        },
        zh: { 
            message: {
                title: 'Bcrypt',
                encode_text: '加密',              
                rounds: 'Rounds',
            }
        },
    }
}