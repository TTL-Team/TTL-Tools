module.exports = { 
    messages: {
        en: { 
            message: {
                title: 'MD5',
                encode_text: 'Encrypt',               
                digits: 'Digits',               
            }
            
        },
        zh: { 
            message: {
                title: 'MD5',
                encode_text: '加密',
                digits: 'Digits',   
            }
        },
    }
}