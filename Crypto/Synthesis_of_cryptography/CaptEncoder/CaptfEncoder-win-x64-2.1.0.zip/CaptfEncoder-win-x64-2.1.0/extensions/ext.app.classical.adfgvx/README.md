ADFGVX Cipher（ADFGVX 密码）
=======================================


ADFGVX 密码实际上就是ADFGX密码的扩充升级版，一样具有 ADFGX 密码相同的特点，加密过程也类似，不同的是密文字母增加了V，使得可以再使用10数字来替换明文。

    A D F G V X
  -------------
A | p h 0 q g 6
D | 4 m e a 1 y
F | l 2 n o f d
G | x k r 3 c v
V | s 5 z w 7 b
X | j 9 u t i 8