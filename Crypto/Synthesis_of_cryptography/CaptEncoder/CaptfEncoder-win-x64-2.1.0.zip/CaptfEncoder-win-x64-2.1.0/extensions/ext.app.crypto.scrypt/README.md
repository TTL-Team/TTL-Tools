Scrypt
==============

Scrypt是内存依赖型的POW算法，莱特币采用此算法。