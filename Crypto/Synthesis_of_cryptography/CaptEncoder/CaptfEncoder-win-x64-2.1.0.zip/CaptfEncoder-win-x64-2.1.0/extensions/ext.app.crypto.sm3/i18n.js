module.exports = { 
    messages: {
        en: { 
            message: {
                title: 'SM3',
                encode_text: 'Encrypt',               
            }
            
        },
        zh: { 
            message: {
                title: 'SM3',
                encode_text: '加密',              
            }
        },
    }
}