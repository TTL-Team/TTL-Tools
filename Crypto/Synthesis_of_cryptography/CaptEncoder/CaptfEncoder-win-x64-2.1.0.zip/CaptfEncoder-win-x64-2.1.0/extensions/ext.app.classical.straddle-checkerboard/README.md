Straddle Checkerboard Cipher（跨棋盘密码）
=================================================

跨棋盘密码(Straddle Checkerboard Cipher)是一种替换密码，当这种密码在结合其他加密方式，加密效果会更好。