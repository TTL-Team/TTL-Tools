module.exports = { 
    messages: {
        en: { 
            message: {
                title: 'MD series',
                encode_text: 'Encrypt',              
                type: 'Type'
            }
            
        },
        zh: { 
            message: {
                title: 'MD 系列',
                encode_text: '加密',
                type: 'Type'
            }
        },
    }
}