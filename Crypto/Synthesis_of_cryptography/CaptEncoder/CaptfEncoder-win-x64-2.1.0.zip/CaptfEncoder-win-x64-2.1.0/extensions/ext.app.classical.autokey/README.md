Autokey Cipher（自动密钥密码）
=======================================

自动密钥密码(Autokey Cipher)是多表替换密码，与维吉尼亚密码密切相关，但使用不同的方法生成密钥，通常来说要比维吉尼亚密码更安全。自动密钥密码主要有两种，关键词自动密钥密码和原文自动密钥密码.下面我们以关键词自动密钥为例：

明文： THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG

关键词： CULTURE

自动生成密钥： CULTURE THE QUICK BROWN FOX JUMPS OVER THE

接下来的加密过程和维吉尼亚密码类似，从密表可得：

密文： VBP JOZGD IVEQV HYY AIICX CSNL FWW ZVDP WVK