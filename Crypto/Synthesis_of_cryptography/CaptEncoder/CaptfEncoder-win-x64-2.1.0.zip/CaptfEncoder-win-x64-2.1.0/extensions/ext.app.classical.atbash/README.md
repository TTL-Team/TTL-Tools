Atbash Cipher（埃特巴什码）
=======================================

埃特巴什码(Atbash Cipher)是一种以字母倒序排列作为特殊密钥的替换加密，也就是下面的对应关系：

ABCDEFGHIJKLMNOPQRSTUVWXYZ

ZYXWVUTSRQPONMLKJIHGFEDCBA

明文： the quick brown fox jumps over the lazy dog

密文： gsv jfrxp yildm ulc qfnkh levi gsv ozab wlt
