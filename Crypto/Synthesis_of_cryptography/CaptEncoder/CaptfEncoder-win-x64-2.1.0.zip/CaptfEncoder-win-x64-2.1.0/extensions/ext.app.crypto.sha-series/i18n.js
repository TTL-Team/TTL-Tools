module.exports = { 
    messages: {
        en: { 
            message: {
                title: 'SHA series',
                encode_text: 'Encrypt',
                type: 'Type'
            }
            
        },
        zh: { 
            message: {
                title: 'SHA 系列',
                encode_text: '加密',
                type: 'Type'
            }
        },
    }
}