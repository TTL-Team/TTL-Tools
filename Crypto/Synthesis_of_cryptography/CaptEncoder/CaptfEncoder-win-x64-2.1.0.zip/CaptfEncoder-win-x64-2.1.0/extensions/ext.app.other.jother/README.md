Jother 编码
==========================
















## Reference 

 * <http://tmxk.org/jother/>