Gif extractor
================




