module.exports = { 
    messages: {
        en: { 
            message: {
                title: 'CRC encoding',
                encode_text: 'Encode',               
                type: 'Type'           
            }
            
        },
        zh: { 
            message: {
                title: 'CRC 编码',
                encode_text: '编码',               
                type: 'Type'            
            }
        },
    }
}