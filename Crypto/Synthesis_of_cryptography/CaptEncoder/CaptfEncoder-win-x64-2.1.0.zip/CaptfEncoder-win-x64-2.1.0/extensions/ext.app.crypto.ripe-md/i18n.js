module.exports = { 
    messages: {
        en: { 
            message: {
                title: 'RIPEMD',
                encode_text: 'Encrypt',
                length: 'Length',              
            }
            
        },
        zh: { 
            message: {
                title: 'RIPEMD',
                encode_text: '加密',
                length: 'Length',  
            }
        },
    }
}