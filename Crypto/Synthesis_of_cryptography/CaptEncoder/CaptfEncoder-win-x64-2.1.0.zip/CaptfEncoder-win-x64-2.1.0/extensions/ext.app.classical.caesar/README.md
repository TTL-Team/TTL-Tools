Caesar Cipher（凯撒密码）
=======================================


凯撒密码(Caesar Cipher或称恺撒加密、恺撒变换、变换加密、位移加密)是一种替换加密，明文中的所有字母都在字母表上向后（或向前）按照一个固定数目进行偏移后被替换成密文。例，当偏移量是3的时候，所有的字母A将被替换成D，B变成E，以此类推。

加密实例：

明文： The quick brown fox jumps over the lazy dog

偏移量：1

密文： Uif rvjdl cspxo gpy kvnqt pwfs uif mbaz eph